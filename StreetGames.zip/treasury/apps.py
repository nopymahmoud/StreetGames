from django.apps import AppConfig


class TreasuryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'treasury'
    verbose_name = 'إدارة الخزينة والبنوك'
