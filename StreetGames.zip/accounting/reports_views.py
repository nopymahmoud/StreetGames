from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import datetime, timedelta
from decimal import Decimal
import json

from .models import ChartOfAccounts, JournalEntry, JournalEntryLine, DailyRevenue
from .expense_models import Expense
from partnerships.models import Partnership, PartnerAccount
from core.decorators import accounting_access_required


def _account_balance_as_of(account, as_of_date=None, currency: str | None = None):
    """حساب رصيد الحساب حتى تاريخ معين اعتماداً على قيود اليومية + الرصيد الافتتاحي.
    - إذا تم تحديد العملة: يتم جمع قيود اليومية بتلك العملة فقط،
      كما لا يُحتسب الرصيد الافتتاحي إلا إذا كانت عملة الحساب تطابق العملة المحددة.
    - النتيجة تكون باتجاه طبيعة الحساب (debit/credit) كقيمة موجبة.
    """
    qs = JournalEntryLine.objects.filter(account=account, journal_entry__posted=True)
    if as_of_date:
        qs = qs.filter(journal_entry__entry_date__lte=as_of_date)
    if currency:
        qs = qs.filter(currency=currency)
    sums = qs.aggregate(total_debit=Sum('debit'), total_credit=Sum('credit'))
    total_debit = sums['total_debit'] or Decimal('0')
    total_credit = sums['total_credit'] or Decimal('0')

    opening = account.opening_balance or Decimal('0')
    if currency and account.currency != currency:
        opening = Decimal('0')

    if account.balance_type == 'debit':
        balance = opening + total_debit - total_credit
    else:
        balance = opening + total_credit - total_debit
    return balance


@accounting_access_required
def reports_dashboard(request):
    """لوحة تحكم التقارير"""
    context = {
        'title': 'التقارير المحاسبية',
    }
    return render(request, 'accounting/reports_dashboard.html', context)


@accounting_access_required
def balance_sheet(request):
    """الميزانية العمومية"""
    # الحصول على المناطق المسموحة للمستخدم
    if hasattr(request.user, 'userprofile'):
        accessible_zones = request.user.userprofile.get_accessible_zones()
    else:
        accessible_zones = []
    
    # تاريخ التقرير (افتراضياً نهاية الشهر الحالي)
    report_date = request.GET.get('date')
    if report_date:
        report_date = datetime.strptime(report_date, '%Y-%m-%d').date()
    else:
        report_date = timezone.now().date()
    
    # الأصول
    assets = ChartOfAccounts.objects.filter(
        account_type='asset',
        active=True
    ).order_by('account_code')

    # الخصوم
    liabilities = ChartOfAccounts.objects.filter(
        account_type='liability',
        active=True
    ).order_by('account_code')

    # حقوق الملكية
    equity = ChartOfAccounts.objects.filter(
        account_type='equity',
        active=True
    ).order_by('account_code')

    # حساب الأرصدة حتى تاريخ التقرير
    for acc in list(assets) + list(liabilities) + list(equity):
        acc.computed_balance = _account_balance_as_of(acc, report_date)

    # حساب الإجماليات من computed_balance
    total_assets = sum((a.computed_balance or Decimal('0') for a in assets), Decimal('0'))
    total_liabilities = sum((l.computed_balance or Decimal('0') for l in liabilities), Decimal('0'))
    total_equity = sum((e.computed_balance or Decimal('0') for e in equity), Decimal('0'))

    # حساب صافي الدخل للفترة حسب العملة
    current_month = report_date.replace(day=1)
    next_month = (current_month + timedelta(days=32)).replace(day=1)

    # الإيرادات حسب العملة
    monthly_revenue_by_currency = DailyRevenue.objects.filter(
        zone__in=accessible_zones,
        date__gte=current_month,
        date__lt=next_month
    ).values('currency').annotate(
        total=Sum('amount')
    ).order_by('currency')

    # المصروفات حسب العملة
    monthly_expenses_by_currency = Expense.objects.filter(
        zone__in=accessible_zones,
        date__gte=current_month,
        date__lt=next_month
    ).values('currency').annotate(
        total=Sum('amount')
    ).order_by('currency')

    # حساب صافي الدخل لكل عملة
    net_income_by_currency = {}
    all_currencies = set()

    # جمع جميع العملات
    for revenue in monthly_revenue_by_currency:
        all_currencies.add(revenue['currency'])
    for expense in monthly_expenses_by_currency:
        all_currencies.add(expense['currency'])

    # حساب صافي الدخل لكل عملة
    for currency in all_currencies:
        revenue_total = next((r['total'] for r in monthly_revenue_by_currency if r['currency'] == currency), Decimal('0'))
        expense_total = next((e['total'] for e in monthly_expenses_by_currency if e['currency'] == currency), Decimal('0'))
        net_income_by_currency[currency] = revenue_total - expense_total
    
    context = {
        'report_date': report_date,
        'assets': assets,
        'liabilities': liabilities,
        'equity': equity,
        'total_assets': total_assets,
        'total_liabilities': total_liabilities,
        'total_equity': total_equity,
        'monthly_revenue_by_currency': monthly_revenue_by_currency,
        'monthly_expenses_by_currency': monthly_expenses_by_currency,
        'net_income_by_currency': net_income_by_currency,
        'all_currencies': sorted(all_currencies),
    }
    return render(request, 'accounting/balance_sheet.html', context)


@accounting_access_required
def income_statement(request):
    """قائمة الدخل"""
    # الحصول على المناطق المسموحة للمستخدم
    if hasattr(request.user, 'userprofile'):
        accessible_zones = request.user.userprofile.get_accessible_zones()
    else:
        accessible_zones = []
    
    # فترة التقرير
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    
    if date_from and date_to:
        date_from = datetime.strptime(date_from, '%Y-%m-%d').date()
        date_to = datetime.strptime(date_to, '%Y-%m-%d').date()
    else:
        # افتراضياً الشهر الحالي
        date_from = timezone.now().replace(day=1).date()
        date_to = (date_from + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    
    # الإيرادات حسب العملة والمنطقة
    revenues_by_currency = DailyRevenue.objects.filter(
        zone__in=accessible_zones,
        date__gte=date_from,
        date__lte=date_to
    ).values('currency', 'zone__name').annotate(
        total_amount=Sum('amount'),
        count=Count('id')
    ).order_by('currency', 'zone__name')

    # إجمالي الإيرادات حسب العملة
    total_revenue_by_currency = DailyRevenue.objects.filter(
        zone__in=accessible_zones,
        date__gte=date_from,
        date__lte=date_to
    ).values('currency').annotate(
        total=Sum('amount')
    ).order_by('currency')

    # المصروفات حسب العملة والفئة
    expenses_by_currency = Expense.objects.filter(
        zone__in=accessible_zones,
        date__gte=date_from,
        date__lte=date_to
    ).values('currency', 'category').annotate(
        total_amount=Sum('amount'),
        count=Count('id')
    ).order_by('currency', 'category')

    # إجمالي المصروفات حسب العملة
    total_expenses_by_currency = Expense.objects.filter(
        zone__in=accessible_zones,
        date__gte=date_from,
        date__lte=date_to
    ).values('currency').annotate(
        total=Sum('amount')
    ).order_by('currency')

    # حساب صافي الدخل لكل عملة
    net_income_by_currency = {}
    all_currencies = set()

    # جمع جميع العملات
    for revenue in total_revenue_by_currency:
        all_currencies.add(revenue['currency'])
    for expense in total_expenses_by_currency:
        all_currencies.add(expense['currency'])

    # حساب صافي الدخل لكل عملة
    for currency in all_currencies:
        revenue_total = next((r['total'] for r in total_revenue_by_currency if r['currency'] == currency), Decimal('0'))
        expense_total = next((e['total'] for e in total_expenses_by_currency if e['currency'] == currency), Decimal('0'))
        net_income_by_currency[currency] = revenue_total - expense_total
    
    context = {
        'date_from': date_from,
        'date_to': date_to,
        'revenues_by_currency': revenues_by_currency,
        'expenses_by_currency': expenses_by_currency,
        'total_revenue_by_currency': total_revenue_by_currency,
        'total_expenses_by_currency': total_expenses_by_currency,
        'net_income_by_currency': net_income_by_currency,
        'all_currencies': sorted(all_currencies),
        'accessible_zones': accessible_zones,
    }
    return render(request, 'accounting/income_statement.html', context)


@accounting_access_required
def trial_balance(request):
    """ميزان المراجعة"""
    # تاريخ التقرير
    report_date = request.GET.get('as_of_date') or request.GET.get('date')
    if report_date:
        report_date = datetime.strptime(report_date, '%Y-%m-%d').date()
    else:
        report_date = timezone.now().date()

    # فلترة عملة اختيارية
    selected_currency = request.GET.get('currency') or None

    # جميع الحسابات النشطة
    accounts = ChartOfAccounts.objects.filter(active=True).order_by('account_code')

    # حساب الأرصدة لكل حساب حتى تاريخ التقرير
    trial_balance_data = []
    total_debit = Decimal('0')
    total_credit = Decimal('0')

    for account in accounts:
        balance = _account_balance_as_of(account, report_date, selected_currency)

        if account.balance_type == 'debit':
            debit_balance = balance if balance > 0 else Decimal('0')
            credit_balance = abs(balance) if balance < 0 else Decimal('0')
        else:
            credit_balance = balance if balance > 0 else Decimal('0')
            debit_balance = abs(balance) if balance < 0 else Decimal('0')

        if debit_balance > 0 or credit_balance > 0:
            trial_balance_data.append({
                'account': account,
                'debit_balance': debit_balance,
                'credit_balance': credit_balance,
            })

            total_debit += debit_balance
            total_credit += credit_balance

    context = {
        'report_date': report_date,
        'today': timezone.now().date(),
        'trial_balance_data': trial_balance_data,
        'total_debit': total_debit,
        'total_credit': total_credit,
        'balance_difference': total_debit - total_credit,
    }
    return render(request, 'accounting/trial_balance.html', context)


@accounting_access_required
def partner_statements(request):
    """كشوف حسابات الشركاء"""
    # الحصول على المناطق المسموحة للمستخدم
    if hasattr(request.user, 'userprofile'):
        accessible_zones = request.user.userprofile.get_accessible_zones()
    else:
        accessible_zones = []
    
    # فترة التقرير
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    partner_id = request.GET.get('partner_id')
    
    if date_from and date_to:
        date_from = datetime.strptime(date_from, '%Y-%m-%d').date()
        date_to = datetime.strptime(date_to, '%Y-%m-%d').date()
    else:
        # افتراضياً الشهر الحالي
        date_from = timezone.now().replace(day=1).date()
        date_to = (date_from + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    
    # الشراكات المتاحة
    partnerships = Partnership.objects.filter(
        zone__in=accessible_zones,
        active=True
    ).select_related('zone').order_by('zone__name', 'partner_name')
    
    # تصفية حسب الشريك المحدد
    if partner_id:
        selected_partnership = partnerships.filter(id=partner_id).first()
        if selected_partnership:
            # كشف حساب الشريك المحدد
            accounts = PartnerAccount.objects.filter(
                partnership=selected_partnership,
                transaction_date__gte=date_from,
                transaction_date__lte=date_to
            ).order_by('transaction_date', 'created_at')
            
            # حساب الرصيد الافتتاحي
            opening_balance = PartnerAccount.objects.filter(
                partnership=selected_partnership,
                transaction_date__lt=date_from
            ).aggregate(
                total_debit=Sum('debit'),
                total_credit=Sum('credit')
            )
            
            opening_balance_amount = (
                (opening_balance['total_debit'] or Decimal('0')) - 
                (opening_balance['total_credit'] or Decimal('0'))
            )
            
            context = {
                'date_from': date_from,
                'date_to': date_to,
                'partnerships': partnerships,
                'selected_partnership': selected_partnership,
                'accounts': accounts,
                'opening_balance': opening_balance_amount,
            }
        else:
            context = {
                'date_from': date_from,
                'date_to': date_to,
                'partnerships': partnerships,
                'error': 'الشريك المحدد غير موجود أو غير متاح',
            }
    else:
        # ملخص جميع الشركاء
        partner_summaries = []
        for partnership in partnerships:
            summary = PartnerAccount.objects.filter(
                partnership=partnership,
                transaction_date__gte=date_from,
                transaction_date__lte=date_to
            ).aggregate(
                total_debit=Sum('debit'),
                total_credit=Sum('credit')
            )
            
            net_balance = (
                (summary['total_debit'] or Decimal('0')) - 
                (summary['total_credit'] or Decimal('0'))
            )
            
            if summary['total_debit'] or summary['total_credit']:
                partner_summaries.append({
                    'partnership': partnership,
                    'total_debit': summary['total_debit'] or Decimal('0'),
                    'total_credit': summary['total_credit'] or Decimal('0'),
                    'net_balance': net_balance,
                })
        
        context = {
            'date_from': date_from,
            'date_to': date_to,
            'partnerships': partnerships,
            'partner_summaries': partner_summaries,
        }
    
    return render(request, 'accounting/partner_statements.html', context)
