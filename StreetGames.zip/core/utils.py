from typing import List, Tuple

def get_supported_currencies() -> List[Tuple[str, str]]:
    """ارجع قائمة العملات المسجلة بالنظام بصيغة [(code, label_ar)]
    المصدر الأساسي: خزائن Treasury (عملة فريدة لكل خزينة)
    fallback: قائمة افتراضية شائعة إن لم توجد خزائن
    """
    try:
        from treasury.models import Treasury
        codes = list(Treasury.objects.values_list('currency', flat=True).order_by('currency').distinct())
    except Exception:
        codes = []

    if not codes:
        codes = ['EGP', 'USD', 'EUR']

    names = {
        'EGP': 'جنيه مصري',
        'USD': 'دولار أمريكي',
        'EUR': 'يورو',
        'SAR': 'ريال سعودي',
        'AED': 'درهم إماراتي',
        'KWD': 'دينار كويتي',
        'QAR': 'ريال قطري',
        'OMR': 'ريال عُماني',
        'GBP': 'جنيه استرليني',
    }
    return [(code, names.get(code, code)) for code in codes]

