from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import datetime, timedelta
from decimal import Decimal
import json

from .models import Hotel, GameZone, GameType, Warehouse


@login_required
def dashboard_stats_api(request):
    """API لإحصائيات لوحة التحكم"""
    try:
        # الحصول على المناطق المسموحة للمستخدم
        if hasattr(request.user, 'userprofile'):
            accessible_zones = request.user.userprofile.get_accessible_zones()
        else:
            accessible_zones = GameZone.objects.none()
        
        # إحصائيات أساسية
        stats = {
            'total_hotels': Hotel.objects.filter(active=True).count(),
            'total_zones': accessible_zones.count(),
            'total_game_types': GameType.objects.filter(active=True).count(),
            'total_warehouses': Warehouse.objects.filter(active=True).count(),
        }
        
        # إحصائيات الشراكات
        try:
            from partnerships.models import Partnership
            stats['total_partnerships'] = Partnership.objects.filter(
                zone__in=accessible_zones, 
                active=True
            ).count()
        except ImportError:
            stats['total_partnerships'] = 0
        
        # إحصائيات مالية
        current_month = timezone.now().replace(day=1)
        next_month = (current_month + timedelta(days=32)).replace(day=1)
        
        try:
            from accounting.models import DailyRevenue
            from accounting.expense_models import Expense
            
            monthly_revenue = DailyRevenue.objects.filter(
                zone__in=accessible_zones,
                date__gte=current_month,
                date__lt=next_month
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
            
            monthly_expenses = Expense.objects.filter(
                zone__in=accessible_zones,
                date__gte=current_month,
                date__lt=next_month
            ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
            
            stats.update({
                'monthly_revenue': float(monthly_revenue),
                'monthly_expenses': float(monthly_expenses),
                'monthly_profit': float(monthly_revenue - monthly_expenses),
            })
        except ImportError:
            stats.update({
                'monthly_revenue': 0,
                'monthly_expenses': 0,
                'monthly_profit': 0,
            })
        
        # إحصائيات الخزينة
        try:
            from treasury.models import Treasury, BankAccount
            
            treasury_balance = Treasury.objects.aggregate(
                total=Sum('balance')
            )['total'] or Decimal('0')
            
            bank_balance = BankAccount.objects.filter(active=True).aggregate(
                total=Sum('current_balance')
            )['total'] or Decimal('0')
            
            stats.update({
                'treasury_balance': float(treasury_balance),
                'bank_balance': float(bank_balance),
                'total_cash': float(treasury_balance + bank_balance),
            })
        except ImportError:
            stats.update({
                'treasury_balance': 0,
                'bank_balance': 0,
                'total_cash': 0,
            })
        
        return JsonResponse({'success': True, 'data': stats})
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def revenue_chart_api(request):
    """API لبيانات مخطط الإيرادات"""
    try:
        # الحصول على المناطق المسموحة للمستخدم
        if hasattr(request.user, 'userprofile'):
            accessible_zones = request.user.userprofile.get_accessible_zones()
        else:
            accessible_zones = GameZone.objects.none()
        
        # الحصول على بيانات آخر 6 أشهر
        months_data = []
        current_date = timezone.now().replace(day=1)
        
        try:
            from accounting.models import DailyRevenue
            from accounting.expense_models import Expense
            
            for i in range(6):
                month_start = (current_date - timedelta(days=32*i)).replace(day=1)
                month_end = (month_start + timedelta(days=32)).replace(day=1)
                
                revenue = DailyRevenue.objects.filter(
                    zone__in=accessible_zones,
                    date__gte=month_start,
                    date__lt=month_end
                ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
                
                expenses = Expense.objects.filter(
                    zone__in=accessible_zones,
                    date__gte=month_start,
                    date__lt=month_end
                ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
                
                months_data.insert(0, {
                    'month': month_start.strftime('%Y-%m'),
                    'month_name': month_start.strftime('%B %Y'),
                    'revenue': float(revenue),
                    'expenses': float(expenses),
                    'profit': float(revenue - expenses)
                })
        except ImportError:
            # بيانات وهمية للاختبار
            months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو']
            for i, month in enumerate(months):
                months_data.append({
                    'month': f"2024-{i+1:02d}",
                    'month_name': month,
                    'revenue': 120000 + (i * 5000),
                    'expenses': 80000 + (i * 2000),
                    'profit': 40000 + (i * 3000)
                })
        
        return JsonResponse({'success': True, 'data': months_data})
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def zone_revenue_distribution_api(request):
    """API لتوزيع الإيرادات حسب المنطقة"""
    try:
        # الحصول على المناطق المسموحة للمستخدم
        if hasattr(request.user, 'userprofile'):
            accessible_zones = request.user.userprofile.get_accessible_zones()
        else:
            accessible_zones = GameZone.objects.none()
        
        # الحصول على إيرادات الشهر الحالي لكل منطقة
        current_month = timezone.now().replace(day=1)
        next_month = (current_month + timedelta(days=32)).replace(day=1)
        
        zones_data = []
        
        try:
            from accounting.models import DailyRevenue
            
            for zone in accessible_zones:
                revenue = DailyRevenue.objects.filter(
                    zone=zone,
                    date__gte=current_month,
                    date__lt=next_month
                ).aggregate(total=Sum('amount'))['total'] or Decimal('0')
                
                if revenue > 0:
                    zones_data.append({
                        'zone_name': zone.name,
                        'zone_code': zone.code,
                        'revenue': float(revenue)
                    })
        except ImportError:
            # بيانات وهمية للاختبار
            for zone in accessible_zones[:4]:  # أول 4 مناطق فقط
                zones_data.append({
                    'zone_name': zone.name,
                    'zone_code': zone.code,
                    'revenue': 25000 + (len(zones_data) * 5000)
                })
        
        # أعلى 5 مناطق
        zones_data.sort(key=lambda x: x['revenue'], reverse=True)
        zones_data = zones_data[:5]
        return JsonResponse({'success': True, 'data': zones_data})
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def recent_activities_api(request):
    """API لآخر الأنشطة"""
    try:
        # الحصول على المناطق المسموحة للمستخدم
        if hasattr(request.user, 'userprofile'):
            accessible_zones = request.user.userprofile.get_accessible_zones()
        else:
            accessible_zones = GameZone.objects.none()
        
        activities = []
        
        try:
            from accounting.models import DailyRevenue
            from accounting.expense_models import Expense
            
            # آخر الإيرادات
            recent_revenues = DailyRevenue.objects.filter(
                zone__in=accessible_zones
            ).select_related('zone').order_by('-date', '-created_at')[:5]
            
            for revenue in recent_revenues:
                activities.append({
                    'type': 'revenue',
                    'date': revenue.date.strftime('%Y-%m-%d'),
                    'description': f"إيراد {revenue.zone.name}",
                    'amount': float(revenue.amount),
                    'currency': revenue.currency
                })
            
            # آخر المصروفات
            recent_expenses = Expense.objects.filter(
                zone__in=accessible_zones
            ).select_related('zone').order_by('-date', '-created_at')[:5]
            
            for expense in recent_expenses:
                activities.append({
                    'type': 'expense',
                    'date': expense.date.strftime('%Y-%m-%d'),
                    'description': f"مصروف {expense.get_category_display()} - {expense.zone.name}",
                    'amount': float(expense.amount),
                    'currency': expense.currency
                })
            
            # ترتيب الأنشطة حسب التاريخ
            activities.sort(key=lambda x: x['date'], reverse=True)
            activities = activities[:10]  # أحدث 10 أنشطة
            
        except ImportError:
            activities = []
        
        return JsonResponse({'success': True, 'data': activities})
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})
