from django.apps import AppConfig


class PartnershipsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'partnerships'
    verbose_name = 'إدارة الشراكات'
